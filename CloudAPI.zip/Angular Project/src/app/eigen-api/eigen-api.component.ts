import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eigen-api',
  templateUrl: './eigen-api.component.html',
  styleUrls: ['./eigen-api.component.scss']
})
export class EigenApiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
