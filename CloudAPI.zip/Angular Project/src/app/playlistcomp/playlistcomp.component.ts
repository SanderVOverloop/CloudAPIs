import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-playlistcomp',
  templateUrl: './playlistcomp.component.html',
  styleUrls: ['./playlistcomp.component.scss']
})
export class PlaylistcompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
